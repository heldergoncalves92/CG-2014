//
//  motor.h
//  Motor3D
//
//  Created by Hélder José Alves Gonçalves on 12/03/14.
//  Copyright (c) 2014 Duarte Nuno Ferreira Duarte. All rights reserved.
//

#ifndef Motor3D_motor_h
#define Motor3D_motor_h

#include <GLUT/glut.h>
#include <stdio.h>
#include "tinyxml/tinyxml.h"

void motor_XML(TiXmlNode *doc);

#endif
