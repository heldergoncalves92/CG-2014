//
//  paralelepipedo.h
//  CG-FORMAS-PRIMARIAS
//
//  Created by Hélder José Alves Gonçalves on 10/03/14.
//  Copyright (c) 2014 Hélder José Alves Gonçalves. All rights reserved.
//

#ifndef CG_FORMAS_PRIMARIAS_paralelepipedo_h
#define CG_FORMAS_PRIMARIAS_paralelepipedo_h

#include "plano.h"

void paralelepipedo(float altura, float lado_x, float lado_z, int camadas, int fatias, FILE* f);

#endif